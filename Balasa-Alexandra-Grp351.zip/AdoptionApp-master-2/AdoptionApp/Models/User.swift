
import Foundation

class User {
    var uid: String
    var photoURL: URL
    var firstname: String
    var lastname: String
    var city: String
    var street: String
    
    
    init(uid: String, photoURL: String, firstname: String, lastname: String, city: String, street: String) {
        self.uid = uid
        self.photoURL = URL(string: photoURL)!
        self.firstname = firstname
        self.lastname = lastname
        self.city = city
        self.street = street
    }
}
